def hello(a,b,c):
    return a+b+c

d=30